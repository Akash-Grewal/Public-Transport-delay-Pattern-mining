"""Data validation, cleaning and delay calculation (FR-01, FR-02, FR-03)."""
import pandas as pd

from . import config


def load_data(path):
    """FR-01: import a structured CSV file (everything read as text first)."""
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def validate_columns(df, required=None):
    """FR-02: required fields must exist; raise a clear error otherwise."""
    required = required or config.REQUIRED_COLUMNS
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")


def assign_delay_label(delay_minutes, threshold=config.DELAY_THRESHOLD_MIN):
    """1 = Delayed (delay strictly greater than threshold), 0 = On-time."""
    return (delay_minutes > threshold).astype(int)


def clean(df, threshold=config.DELAY_THRESHOLD_MIN, max_abs_delay=config.MAX_ABS_DELAY_MIN):
    """Clean raw records using documented rules.

    Returns (clean_df, rejected_df, report). Nothing is silently dropped:
    every rejected row carries a reason and is counted in the report.
    Missing optional fields (weather, traffic) are NOT invented; they stay NA.
    """
    validate_columns(df)
    df = df.copy()
    report = {"rows_loaded": int(len(df))}

    for col in ("trip_id", "route_id", "stop_id"):
        df[col] = df[col].astype(str).str.strip().str.upper()
    for col in config.OPTIONAL_COLUMNS:
        if col in df.columns:
            s = df[col].astype(str).str.strip().str.title()
            df[col] = s.where(~s.isin(["", "Nan", "None", "Na"]), other=pd.NA)
        else:
            df[col] = pd.NA
            report[f"optional_column_absent_{col}"] = True

    df["scheduled_arrival"] = pd.to_datetime(df["scheduled_arrival"], errors="coerce")
    df["actual_arrival"] = pd.to_datetime(df["actual_arrival"], errors="coerce")

    rejected = []

    # 1. missing / unparseable required fields
    id_missing = (df[["trip_id", "route_id", "stop_id"]] == "").any(axis=1)
    time_missing = df["scheduled_arrival"].isna() | df["actual_arrival"].isna()
    miss = id_missing | time_missing
    report["rows_rejected_missing_required"] = int(miss.sum())
    rejected.append(df[miss].assign(reject_reason="missing_or_invalid_required_field"))
    df = df[~miss]

    # 2. duplicate trip-stop records
    dup = df.duplicated(subset=["trip_id", "stop_id"], keep="first")
    report["rows_rejected_duplicate"] = int(dup.sum())
    rejected.append(df[dup].assign(reject_reason="duplicate_trip_stop"))
    df = df[~dup].copy()

    # 3. delay calculation + midnight convention
    df["delay_minutes"] = (df["actual_arrival"] - df["scheduled_arrival"]).dt.total_seconds() / 60.0
    rollover = df["delay_minutes"] < config.MIDNIGHT_ROLLOVER_MIN
    report["rows_midnight_adjusted"] = int(rollover.sum())
    df.loc[rollover, "actual_arrival"] += pd.Timedelta(days=1)
    df["delay_minutes"] = (df["actual_arrival"] - df["scheduled_arrival"]).dt.total_seconds() / 60.0

    # 4. implausible delays
    bad = df["delay_minutes"].abs() > max_abs_delay
    report["rows_rejected_implausible_delay"] = int(bad.sum())
    rejected.append(df[bad].assign(reject_reason=f"abs_delay_over_{int(max_abs_delay)}_min"))
    df = df[~bad].copy()

    # 5. label
    df["delayed"] = assign_delay_label(df["delay_minutes"], threshold)

    rejected_df = pd.concat(rejected, ignore_index=True)
    report["rows_clean"] = int(len(df))
    report["rows_rejected_total"] = int(len(rejected_df))
    report["delay_threshold_minutes"] = threshold
    report["threshold_rule"] = "Delayed if delay_minutes > threshold (equal = On-time)"
    for col in config.OPTIONAL_COLUMNS:
        report[f"missing_{col}_in_clean_rows"] = int(df[col].isna().sum())
    return df.reset_index(drop=True), rejected_df, report

"""Static local dashboard: one self-contained HTML file (no server needed)."""
import base64
import html
import os


def _img(path):
    with open(path, "rb") as f:
        return f"data:image/png;base64,{base64.b64encode(f.read()).decode()}"


def build_dashboard(outdir, chart_paths, report, route_s, tb_s, rules, clus_s, metrics, dataset_note):
    def tbl(df, n=None):
        d = df.head(n) if n else df
        return d.to_html(index=False, classes="t", border=0, float_format=lambda x: f"{x:.3f}")

    dq = "".join(f"<tr><td>{html.escape(str(k))}</td><td>{html.escape(str(v))}</td></tr>" for k, v in report.items())
    dt, bl = metrics["decision_tree"], metrics["majority_baseline"]
    mrow = lambda name, m: (f"<tr><td>{name}</td><td>{m['accuracy']}</td><td>{m['precision']}</td>"
                            f"<td>{m['recall']}</td><td>{m['f1']}</td></tr>")
    imgs = "".join(f'<img src="{_img(p)}" alt="{os.path.basename(p)}">' for p in chart_paths)
    page = f"""<!doctype html><html><head><meta charset="utf-8">
<title>Public Transport Delay Pattern Mining - Dashboard</title>
<style>body{{font-family:Arial,sans-serif;margin:24px;color:#222;max-width:1100px}}
h1{{font-size:22px}}h2{{font-size:17px;border-bottom:1px solid #ccc;padding-bottom:4px;margin-top:28px}}
.note{{background:#fffbea;border-left:4px solid #d69e2e;padding:8px 12px;font-size:13px}}
table{{border-collapse:collapse;font-size:12.5px;margin:6px 0}}td,th{{padding:4px 9px;border-bottom:1px solid #ddd;text-align:left}}
th{{background:#edf2f7}}.imgs img{{width:48%;margin:4px;border:1px solid #eee}}</style></head><body>
<h1>Public Transport Delay Pattern Mining - Dashboard</h1>
<p class="note"><b>Dataset note:</b> {html.escape(dataset_note)}<br>
Associations are not causes. Review rules with a transport domain expert before acting.</p>
<h2>Data quality log</h2><table>{dq}</table>
<h2>Delay by route</h2>{tbl(route_s)}
<h2>Delay by time band</h2>{tbl(tb_s)}
<h2>Charts</h2><div class="imgs">{imgs}</div>
<h2>Top association rules  ( antecedent &rarr; Delayed )</h2>{tbl(rules, 15)}
<h2>Route-segment clusters</h2>{tbl(clus_s)}
<h2>Baseline classifier (held-out chronological test set)</h2>
<table><tr><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1</th></tr>
{mrow('Decision tree', dt)}{mrow('Majority-class baseline', bl)}</table>
<p style="font-size:12px">Train/test: {metrics['split']['train_records']} / {metrics['split']['test_records']} records;
test delayed share {metrics['split']['test_delayed_share']}.</p>
</body></html>"""
    path = os.path.join(outdir, "dashboard.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return path

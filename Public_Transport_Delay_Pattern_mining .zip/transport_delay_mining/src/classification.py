"""Baseline delay classifier with chronological split and leakage guard (FR-07)."""
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier

from . import config

CATEGORICAL = ["route_id", "stop_id", "time_band", "day_type", "day_of_week", "weather", "traffic_level"]
NUMERIC = ["hour"]


def assert_no_leakage(feature_columns):
    bad = set(feature_columns) & set(config.LEAKAGE_COLUMNS)
    if bad:
        raise ValueError(f"Data leakage: outcome-derived columns used as predictors: {sorted(bad)}")


def chronological_split(df, test_fraction=config.TEST_FRACTION):
    """Train on earlier records, test on the latest ones (no future info in training)."""
    df = df.sort_values("scheduled_arrival").reset_index(drop=True)
    cut = int(len(df) * (1 - test_fraction))
    return df.iloc[:cut], df.iloc[cut:]


def _metrics(y_true, y_pred):
    return {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
        "confusion_matrix [[TN, FP], [FN, TP]]": confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist(),
    }


def train_and_evaluate(df):
    features = CATEGORICAL + NUMERIC
    assert_no_leakage(features)
    train, test = chronological_split(df)
    Xtr, Xte = train[features].copy(), test[features].copy()
    for c in ("weather", "traffic_level"):          # explicit 'Unknown' category, not an invented value
        Xtr[c] = Xtr[c].astype(object).where(Xtr[c].notna(), "Unknown")
        Xte[c] = Xte[c].astype(object).where(Xte[c].notna(), "Unknown")
    ytr, yte = train["delayed"], test["delayed"]

    pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL)],
                            remainder="passthrough")
    tree = Pipeline([("pre", pre),
                     ("clf", DecisionTreeClassifier(max_depth=config.TREE_MAX_DEPTH,
                                                    class_weight="balanced",
                                                    random_state=config.RANDOM_STATE))]).fit(Xtr, ytr)
    base = DummyClassifier(strategy="most_frequent").fit(Xtr, ytr)

    names = tree.named_steps["pre"].get_feature_names_out()
    imp = sorted(zip(names, tree.named_steps["clf"].feature_importances_), key=lambda t: -t[1])[:10]
    return {
        "split": {"train_records": int(len(train)), "test_records": int(len(test)),
                  "train_delayed_share": round(float(ytr.mean()), 4),
                  "test_delayed_share": round(float(yte.mean()), 4),
                  "method": "chronological (earliest 80% train / latest 20% test)"},
        "predictors": features,
        "decision_tree": _metrics(yte, tree.predict(Xte)),
        "majority_baseline": _metrics(yte, base.predict(Xte)),
        "top_features": [{"feature": str(n), "importance": round(float(v), 4)} for n, v in imp],
        "note": "Metrics computed on held-out test records only.",
    }

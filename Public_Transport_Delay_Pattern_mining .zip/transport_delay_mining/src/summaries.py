"""Delay summaries by route, stop and time band (FR-04)."""
import pandas as pd


def _summ(df, by):
    g = df.groupby(by, observed=True)
    out = g.agg(records=("delay_minutes", "size"),
                mean_delay=("delay_minutes", "mean"),
                median_delay=("delay_minutes", "median"),
                std_delay=("delay_minutes", "std"),
                delayed_share=("delayed", "mean")).reset_index()
    return out.round(3)


def route_summary(df):
    return _summ(df, "route_id")


def stop_summary(df):
    return _summ(df, ["route_id", "stop_id"])


def time_band_summary(df):
    return _summ(df, "time_band")


def route_time_matrix(df):
    """Share of delayed records per route x time band (for the heatmap)."""
    return df.pivot_table(index="route_id", columns="time_band", values="delayed", aggfunc="mean")

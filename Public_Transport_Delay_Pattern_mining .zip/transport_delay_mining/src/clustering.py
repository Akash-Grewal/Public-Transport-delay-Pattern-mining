"""Cluster route segments by delay profile (FR-06). Features are scaled first."""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

from . import config


def cluster_segments(df, min_records=config.MIN_RECORDS_PER_SEGMENT, max_k=config.MAX_K):
    seg = (df.groupby(["route_id", "stop_id"])
             .agg(records=("delay_minutes", "size"),
                  mean_delay=("delay_minutes", "mean"),
                  std_delay=("delay_minutes", "std"),
                  delayed_share=("delayed", "mean"))
             .reset_index())
    seg = seg[seg["records"] >= min_records].dropna().reset_index(drop=True)
    if len(seg) < 4:
        seg["cluster"] = 0
        seg["profile"] = "Too few segments to cluster"
        return seg, None

    X = StandardScaler().fit_transform(seg[["mean_delay", "std_delay", "delayed_share"]])
    best_k, best_s = 2, -1.0
    for k in range(2, min(max_k, len(seg) - 1) + 1):
        labels = KMeans(n_clusters=k, n_init=10, random_state=config.RANDOM_STATE).fit_predict(X)
        s = silhouette_score(X, labels)
        if s > best_s:
            best_k, best_s = k, s
    km = KMeans(n_clusters=best_k, n_init=10, random_state=config.RANDOM_STATE).fit(X)
    seg["cluster"] = km.labels_

    # Cluster ids are arbitrary; rank by mean delay only to give readable names.
    order = seg.groupby("cluster")["mean_delay"].mean().sort_values().index.tolist()
    names = {}
    for rank, cid in enumerate(order):
        tag = "lowest" if rank == 0 else ("highest" if rank == len(order) - 1 else "intermediate")
        names[cid] = f"Profile {rank + 1}/{len(order)} ({tag} mean delay)"
    seg["profile"] = seg["cluster"].map(names)
    return seg.round(3), {"k": int(best_k), "silhouette": round(float(best_s), 3)}


def cluster_summary(seg):
    return (seg.groupby("profile")
               .agg(segments=("stop_id", "size"), mean_delay=("mean_delay", "mean"),
                    std_delay=("std_delay", "mean"), delayed_share=("delayed_share", "mean"))
               .round(3).reset_index())

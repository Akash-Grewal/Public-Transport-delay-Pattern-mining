"""Association rule mining with a self-contained Apriori (FR-05).

Rules have the fixed consequent {Delayed}. Support, confidence and lift follow
the definitions in report Section 5.3 / 6.6.
"""
from itertools import combinations

import numpy as np
import pandas as pd

from . import config

TARGET_ITEM = "Delayed"


def build_transactions(df):
    """One-hot item matrix. Missing weather/traffic produce NO item (never invented)."""
    items = {}
    for col, prefix in [("route_id", "Route"), ("time_band", "Time"), ("day_type", "Day"),
                        ("weather", "Weather"), ("traffic_level", "Traffic")]:
        if col not in df.columns:
            continue
        for value in df[col].dropna().unique():
            items[f"{prefix}={value}"] = (df[col] == value).fillna(False).to_numpy()
    items[TARGET_ITEM] = df["delayed"].eq(1).to_numpy()
    return pd.DataFrame(items, index=df.index)


def apriori(onehot, min_support=config.MIN_SUPPORT, max_len=config.MAX_ITEMSET_LEN):
    """Level-wise Apriori. Returns {frozenset(items): support}."""
    n = len(onehot)
    cols = list(onehot.columns)
    M = onehot.to_numpy(dtype=bool)
    frequent = {}

    level = {}
    for j, c in enumerate(cols):
        s = M[:, j].sum() / n
        if s >= min_support:
            level[frozenset([c])] = s
    frequent.update(level)

    k = 2
    while level and k <= max_len:
        prev = sorted(tuple(sorted(s)) for s in level)
        candidates = set()
        for a, b in combinations(prev, 2):
            if a[:-1] == b[:-1]:
                cand = frozenset(a) | frozenset(b)
                if all(frozenset(sub) in level for sub in combinations(sorted(cand), k - 1)):
                    candidates.add(cand)
        level = {}
        for cand in candidates:
            idx = [cols.index(c) for c in cand]
            s = M[:, idx].all(axis=1).sum() / n
            if s >= min_support:
                level[cand] = s
        frequent.update(level)
        k += 1
    return frequent


def mine_rules(df, min_support=config.MIN_SUPPORT, min_confidence=config.MIN_CONFIDENCE,
               max_len=config.MAX_ITEMSET_LEN):
    """Rules  {antecedent} -> {Delayed}  sorted by lift, then confidence."""
    cols = ["antecedent", "support", "confidence", "lift", "record_count", "antecedent_count"]
    onehot = build_transactions(df)
    n = len(onehot)
    frequent = apriori(onehot, min_support, max_len)
    base_rate = onehot[TARGET_ITEM].mean()
    rows = []
    for itemset, sup in frequent.items():
        if TARGET_ITEM not in itemset or len(itemset) < 2:
            continue
        ante = itemset - {TARGET_ITEM}
        ante_sup = frequent.get(ante)
        if not ante_sup:
            continue
        conf = sup / ante_sup
        if conf >= min_confidence:
            rows.append({"antecedent": " + ".join(sorted(ante)),
                         "support": sup, "confidence": conf,
                         "lift": conf / base_rate if base_rate > 0 else np.nan,
                         "record_count": int(round(sup * n)),
                         "antecedent_count": int(round(ante_sup * n))})
    if not rows:
        return pd.DataFrame(columns=cols)
    out = pd.DataFrame(rows, columns=cols)
    return out.sort_values(["lift", "confidence"], ascending=False).reset_index(drop=True)

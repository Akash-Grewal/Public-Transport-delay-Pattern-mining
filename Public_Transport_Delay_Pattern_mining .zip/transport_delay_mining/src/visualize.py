"""Charts for the report / dashboard (FR-08)."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from . import summaries


def _save(fig, outdir, name):
    path = os.path.join(outdir, name)
    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)
    return path


def make_charts(df, seg, metrics, outdir):
    os.makedirs(outdir, exist_ok=True)
    paths = []

    rs = summaries.route_summary(df)
    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.bar(rs["route_id"], rs["mean_delay"], color="#2b6cb0", label="Mean delay (min)")
    ax.bar(rs["route_id"], rs["median_delay"], color="#90cdf4", width=0.4, label="Median delay (min)")
    ax.set_title("Delay by route"); ax.set_ylabel("Minutes"); ax.legend()
    paths.append(_save(fig, outdir, "delay_by_route.png"))

    tb = summaries.time_band_summary(df).set_index("time_band")
    fig, ax = plt.subplots(figsize=(6.5, 4))
    (tb["delayed_share"] * 100).plot.bar(ax=ax, color="#dd6b20", rot=20)
    ax.set_title("Share of delayed records by time band"); ax.set_ylabel("% delayed")
    paths.append(_save(fig, outdir, "delayed_share_by_time_band.png"))

    m = summaries.route_time_matrix(df) * 100
    fig, ax = plt.subplots(figsize=(6.5, 4))
    im = ax.imshow(m.to_numpy(), cmap="YlOrRd", aspect="auto")
    ax.set_xticks(range(m.shape[1])); ax.set_xticklabels(m.columns, rotation=20)
    ax.set_yticks(range(m.shape[0])); ax.set_yticklabels(m.index)
    for i in range(m.shape[0]):
        for j in range(m.shape[1]):
            if not np.isnan(m.iat[i, j]):
                ax.text(j, i, f"{m.iat[i, j]:.0f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, label="% delayed"); ax.set_title("% delayed: route x time band")
    paths.append(_save(fig, outdir, "heatmap_route_time.png"))

    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.hist(df["delay_minutes"], bins=50, color="#38a169")
    ax.axvline(df.attrs.get("threshold", 5), color="red", ls="--", label="Delay threshold")
    ax.set_title("Distribution of delay (minutes)"); ax.set_xlabel("Minutes"); ax.legend()
    paths.append(_save(fig, outdir, "delay_histogram.png"))

    if "profile" in seg.columns and seg["profile"].nunique() > 1:
        fig, ax = plt.subplots(figsize=(6.5, 4))
        for p, g in seg.groupby("profile"):
            ax.scatter(g["mean_delay"], g["std_delay"], label=p, s=40)
        ax.set_xlabel("Mean delay (min)"); ax.set_ylabel("Std of delay (min)")
        ax.set_title("Route-segment delay profiles (clusters)"); ax.legend(fontsize=7)
        paths.append(_save(fig, outdir, "clusters.png"))

    cm = np.array(metrics["decision_tree"]["confusion_matrix [[TN, FP], [FN, TP]]"])
    fig, ax = plt.subplots(figsize=(4.2, 4))
    ax.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=13)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["On-time", "Delayed"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["On-time", "Delayed"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title("Confusion matrix (test set)")
    paths.append(_save(fig, outdir, "confusion_matrix.png"))
    return paths

"""Central, documented settings (see report Sections 5.2, 5.3, 5.4)."""

# A record is "Delayed" when delay_minutes is STRICTLY GREATER than this value.
# A delay exactly equal to the threshold is therefore labelled On-time (test T-06).
DELAY_THRESHOLD_MIN = 5.0

# Records with |delay| above this are rejected as implausible (data-entry / clock errors).
MAX_ABS_DELAY_MIN = 180.0

# If actual - scheduled is below this (e.g. -23h) the actual time is assumed to have
# crossed midnight with the date not rolled over, and one day is added (Section 5.2).
MIDNIGHT_ROLLOVER_MIN = -720.0

# Association rule mining
MIN_SUPPORT = 0.03
MIN_CONFIDENCE = 0.60
MAX_ITEMSET_LEN = 4

# Clustering
MIN_RECORDS_PER_SEGMENT = 20
MAX_K = 5

# Classification
TEST_FRACTION = 0.20       # chronological split: last 20% of records are the test set
TREE_MAX_DEPTH = 5

RANDOM_STATE = 42

REQUIRED_COLUMNS = ["trip_id", "route_id", "stop_id", "scheduled_arrival", "actual_arrival"]
OPTIONAL_COLUMNS = ["weather", "traffic_level"]

# Columns derived from the actual arrival time. They reveal the outcome and must
# NEVER be used as predictors (data leakage - Section 5.4).
LEAKAGE_COLUMNS = ["actual_arrival", "delay_minutes", "delayed"]

"""Derived features: time bands, day type (Section 5.1 'Transformation')."""
import pandas as pd


def time_band(hour):
    if 6 <= hour < 10:
        return "Morning peak"
    if 16 <= hour < 20:
        return "Evening peak"
    if hour >= 22 or hour < 5:
        return "Night"
    return "Off-peak"


def add_features(df):
    """Derive features from the SCHEDULED time only (available before arrival)."""
    df = df.copy()
    sched = df["scheduled_arrival"]
    df["hour"] = sched.dt.hour
    df["day_of_week"] = sched.dt.day_name()
    df["day_type"] = (sched.dt.dayofweek >= 5).map({True: "Weekend", False: "Weekday"})
    df["time_band"] = df["hour"].map(time_band)
    return df

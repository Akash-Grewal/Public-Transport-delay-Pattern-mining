"""Generate a SYNTHETIC bus-trip dataset to demonstrate the workflow.

!! This data is simulated. Nothing derived from it describes a real transport
!! system and it must not be presented as actual findings (see report note).

Usage:  python data/generate_sample_data.py
"""
import os
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
ROUTES = {"R01": 1.0, "R02": 2.5, "R03": 0.5, "R04": 3.5, "R05": 1.5, "R06": 2.0}  # base delay (min)
N_STOPS, N_DAYS, TRIPS_PER_ROUTE_DAY = 5, 45, 8
START = pd.Timestamp("2026-01-05")

hour_w = np.array([2, 5, 6, 6, 4, 3, 3, 3, 4, 6, 6, 5, 3, 2, 2, 1, 1, 1, 1.5], float)  # hours 5..23
hour_w /= hour_w.sum()
hours = np.arange(5, 24)

days = [START + pd.Timedelta(days=i) for i in range(N_DAYS)]
weather_by_day = {d: rng.choice(["Clear", "Rain", "Fog"], p=[0.6, 0.3, 0.1]) for d in days}

rows = []
for d in days:
    for route, base in ROUTES.items():
        for t in range(TRIPS_PER_ROUTE_DAY):
            h = int(rng.choice(hours, p=hour_w))
            start = d + pd.Timedelta(hours=h, minutes=int(rng.integers(40, 60) if h == 23 else rng.integers(0, 60)))
            evening = 16 <= h < 20
            morning = 6 <= h < 10
            p_high = 0.55 if (evening or morning) else 0.15
            traffic = rng.choice(["High", "Medium", "Low"],
                                 p=[p_high, 0.35, 0.65 - p_high]) if p_high < 0.65 else "High"
            weather = weather_by_day[d]
            trip_id = f"{route}-{d:%Y%m%d}-{t:02d}"
            for k in range(N_STOPS):
                sched = start + pd.Timedelta(minutes=7 * k)
                mu = base + 0.6 * k
                mu += 3.5 if evening else (2.0 if morning else 0.0)
                mu += {"High": 3.5, "Medium": 1.0, "Low": 0.0}[traffic]
                mu += {"Rain": 2.0, "Fog": 1.5, "Clear": 0.0}[weather]
                delay = rng.normal(mu - 2.0, 2.2) + (rng.exponential(2.5) if rng.random() < 0.08 else 0)
                actual = sched + pd.Timedelta(seconds=float(delay) * 60)
                rows.append(dict(trip_id=trip_id, route_id=route, stop_id=f"{route}-S{k + 1}",
                                 scheduled_arrival=sched, actual_arrival=actual,
                                 weather=weather, traffic_level=traffic))

df = pd.DataFrame(rows)

# Simulate real-world dirtiness (so the cleaning rules have something to do) -----------
n = len(df)
# some trips crossing midnight have the actual DATE not rolled over (clock-time only logged)
cross = df.index[df["actual_arrival"].dt.normalize() > df["scheduled_arrival"].dt.normalize()]
bad_date = rng.choice(cross, size=max(1, len(cross) // 2), replace=False) if len(cross) else []
new_actual = df["actual_arrival"].copy()
for i in bad_date:
    new_actual.loc[i] = df.at[i, "scheduled_arrival"].normalize() + (
        df.at[i, "actual_arrival"] - df.at[i, "actual_arrival"].normalize())
df["actual_arrival"] = new_actual

df["scheduled_arrival"] = df["scheduled_arrival"].dt.strftime("%Y-%m-%d %H:%M:%S")
df["actual_arrival"] = df["actual_arrival"].dt.strftime("%Y-%m-%d %H:%M:%S")

df.loc[rng.choice(n, int(n * 0.02), replace=False), "actual_arrival"] = ""         # missing actual
df.loc[rng.choice(n, int(n * 0.01), replace=False), "scheduled_arrival"] = ""      # missing scheduled
df.loc[rng.choice(n, int(n * 0.08), replace=False), "weather"] = ""                # weather not recorded
df.loc[rng.choice(n, int(n * 0.05), replace=False), "traffic_level"] = ""          # traffic not recorded
ix = rng.choice(n, int(n * 0.02), replace=False)
df.loc[ix, "route_id"] = " " + df.loc[ix, "route_id"].str.lower()                   # inconsistent route names
imp = rng.choice(n, int(n * 0.005), replace=False)
df.loc[imp, "actual_arrival"] = (pd.to_datetime(df.loc[imp, "scheduled_arrival"], errors="coerce")
                                 + pd.Timedelta(minutes=400)).dt.strftime("%Y-%m-%d %H:%M:%S")  # implausible
df = pd.concat([df, df.sample(int(n * 0.015), random_state=1)], ignore_index=True)  # duplicate rows
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_bus_trips.csv")
df.to_csv(out, index=False)
print(f"Wrote {len(df)} SYNTHETIC rows to {out}")

"""Unit tests mapped to the report's test plan (Section 6.8).  Run:  python -m unittest -v"""
import os
import tempfile
import unittest

import pandas as pd

from src import config
from src.association import mine_rules
from src.classification import assert_no_leakage, chronological_split, train_and_evaluate
from src.features import add_features
from src.preprocessing import clean, load_data, validate_columns


def make(rows):
    cols = ["trip_id", "route_id", "stop_id", "scheduled_arrival", "actual_arrival"]
    return pd.DataFrame(rows, columns=cols + ["weather", "traffic_level"][: len(rows[0]) - 5])


def row(trip, sched, actual, route="R01", stop="S1", *extra):
    return [trip, route, stop, sched, actual, *extra]


class TestPipeline(unittest.TestCase):
    def test_T01_import_valid_csv(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.csv")
            pd.DataFrame([row("T1", "2026-01-05 08:30:00", "2026-01-05 08:38:00")],
                         columns=config.REQUIRED_COLUMNS).to_csv(p, index=False)
            df = load_data(p)
            validate_columns(df)
            self.assertEqual(df.shape, (1, 5))

    def test_T01b_missing_required_column_is_reported(self):
        with self.assertRaises(ValueError):
            validate_columns(pd.DataFrame({"trip_id": ["1"]}))

    def test_T02_missing_timestamp_flagged_no_delay(self):
        df = make([row("T1", "2026-01-05 08:30:00", ""), row("T2", "2026-01-05 08:30:00", "2026-01-05 08:35:00")])
        clean_df, rej, rep = clean(df)
        self.assertEqual(rep["rows_rejected_missing_required"], 1)
        self.assertEqual(list(clean_df["trip_id"]), ["T2"])
        self.assertIn("missing_or_invalid_required_field", set(rej["reject_reason"]))

    def test_T03_duplicate_trip_stop_removed(self):
        r = row("T1", "2026-01-05 08:30:00", "2026-01-05 08:36:00")
        clean_df, _, rep = clean(make([r, r]))
        self.assertEqual(rep["rows_rejected_duplicate"], 1)
        self.assertEqual(len(clean_df), 1)

    def test_T04_late_arrival_positive_delay(self):
        clean_df, _, _ = clean(make([row("T1", "2026-01-05 08:30:00", "2026-01-05 08:38:00")]))
        self.assertEqual(clean_df.loc[0, "delay_minutes"], 8.0)
        self.assertEqual(clean_df.loc[0, "delayed"], 1)

    def test_T05_early_arrival_negative_delay_retained(self):
        clean_df, _, _ = clean(make([row("T1", "2026-01-05 08:30:00", "2026-01-05 08:27:00")]))
        self.assertEqual(clean_df.loc[0, "delay_minutes"], -3.0)
        self.assertEqual(clean_df.loc[0, "delayed"], 0)

    def test_T06_delay_equal_to_threshold_is_on_time(self):
        clean_df, _, _ = clean(make([row("T1", "2026-01-05 08:30:00", "2026-01-05 08:35:00"),
                                     row("T2", "2026-01-05 08:30:00", "2026-01-05 08:35:30")]))
        self.assertEqual(list(clean_df["delayed"]), [0, 1])   # exactly 5.0 -> On-time; 5.5 -> Delayed

    def test_T07_metrics_use_heldout_chronological_test_only(self):
        rows = []
        for i in range(300):
            ts = pd.Timestamp("2026-01-01") + pd.Timedelta(hours=i)
            delay = 9 if ts.hour in (17, 18) else 1
            rows.append(row(f"T{i}", str(ts), str(ts + pd.Timedelta(minutes=delay)), "R01", "S1",
                            "Clear", "High" if delay > 5 else "Low"))
        df = add_features(clean(make(rows))[0])
        train, test = chronological_split(df)
        self.assertLess(train["scheduled_arrival"].max(), test["scheduled_arrival"].min())
        m = train_and_evaluate(df)
        self.assertEqual(m["split"]["test_records"], len(test))
        cm = m["decision_tree"]["confusion_matrix [[TN, FP], [FN, TP]]"]
        self.assertEqual(sum(map(sum, cm)), len(test))        # computed on test rows only
        with self.assertRaises(ValueError):
            assert_no_leakage(["hour", "delay_minutes"])      # leakage guard

    def test_T08_no_weather_field_runs_without_inventing_values(self):
        df = make([row(f"T{i}", "2026-01-05 08:30:00", "2026-01-05 08:40:00", "R01", f"S{i}") for i in range(40)])
        clean_df, _, rep = clean(df)
        self.assertTrue(rep["optional_column_absent_weather"])
        self.assertTrue(clean_df["weather"].isna().all())
        rules = mine_rules(add_features(clean_df), min_support=0.1, min_confidence=0.5)
        self.assertFalse(rules["antecedent"].str.contains("Weather=").any())

    def test_midnight_rollover_adjusted(self):
        clean_df, _, rep = clean(make([row("T1", "2026-01-05 23:55:00", "2026-01-05 00:03:00")]))
        self.assertEqual(rep["rows_midnight_adjusted"], 1)
        self.assertEqual(clean_df.loc[0, "delay_minutes"], 8.0)

    def test_rule_metrics_match_report_example(self):
        # Report 6.6: 100 records; 30 with {Evening peak, High traffic}; 24 of them delayed; 40% delayed overall.
        recs = []
        for i in range(100):
            both = i < 30
            delayed = (i < 24) or (30 <= i < 46)   # 24 + 16 = 40 delayed
            recs.append({"route_id": "R", "time_band": "Evening peak" if both else "Off-peak",
                         "day_type": "Weekday", "weather": pd.NA,
                         "traffic_level": "High" if both else "Low", "delayed": int(delayed)})
        rules = mine_rules(pd.DataFrame(recs), min_support=0.2, min_confidence=0.5)
        r = rules[rules["antecedent"] == "Time=Evening peak + Traffic=High"].iloc[0]
        self.assertAlmostEqual(r["support"], 0.24)
        self.assertAlmostEqual(r["confidence"], 0.80)
        self.assertAlmostEqual(r["lift"], 2.0)


if __name__ == "__main__":
    unittest.main()
